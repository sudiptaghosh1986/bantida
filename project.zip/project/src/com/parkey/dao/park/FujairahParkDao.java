/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.parkey.dao.park;

import java.util.ArrayList;
import java.util.List;


public class FujairahParkDao implements IParkDao {

    @Override
    public String[] getParkNames() {
        List<String> listParkNames=new ArrayList();
        listParkNames.add("-Select-");
        listParkNames.add("Snoopy Island");
        listParkNames.add("Aqua Bounce fujairah");
        listParkNames.add("Divers Down");
      
       
        
        String parknames[]=listParkNames.toArray(new String[listParkNames.size()]);
        return parknames;
    }

    

   
    
}
