package com.parkey.model;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author la6of
 */
public class Location {
    private String city;
    private String parkName;

    public Location(String city, String parkName) {
        this.city = city;
        this.parkName = parkName;
    }

    public String getCity() {
        return city;
    }

    public String getParkName() {
        return parkName;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setParkName(String parkName) {
        this.parkName = parkName;
    }
    
    
    
}
