package com.parkey.model;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author la6of
 */
public class payment {

    private String paymentType;
    private String cardHolder;
    private int cardNum;
    private int CVV;
    private int expDate;

    public payment(String paymentType, String cardHolder, int cardNum, int CVV, int expDate) {

        this.paymentType = paymentType;
        this.cardHolder = cardHolder;
        this.cardNum = cardNum;
        this.CVV = CVV;
        this.expDate = expDate;
    }

    public String getcardHolder() {
        return cardHolder;
    }

    public void setcardHolder(String cardHolder) {
        this.cardHolder = cardHolder;
    }

    public int cardNum() {
        return cardNum;
    }

    public void setcardNum(int cardNum) {
        this.cardNum = cardNum;
    }

    public int CVV() {
        return CVV;
    }

    public void setCVV(int CVV) {
      
        this.CVV = CVV;

    }

    public int expDate() {
        return expDate;
    }

    public void setexpDate(int expDate) {
        this.expDate = expDate;

    }
}


