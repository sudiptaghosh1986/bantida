/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.parkey.dao.park;


import java.util.ArrayList;
import java.util.List;

public class SharjahParkDao implements IParkDao{
    @Override
    public String[] getParkNames() {
        List<String> listParkNames=new ArrayList();
        listParkNames.add("-Select-");
        listParkNames.add("Al Noor island");
        listParkNames.add("Al Montazah");
        listParkNames.add("Buhais Geology Park");
        listParkNames.add("Rain Room");
        listParkNames.add("Sharjah Desert Park");
        listParkNames.add("Sharjah Paint Ball Park");
        
        String parknames[]=listParkNames.toArray(new String[listParkNames.size()]);
        return parknames;
    }
}
