package com.parkey.dao.discount;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author la6of
 */
public class discount  {
    private String discountCard ;
    private double percentage ;
    
    
    public void discount(){
         discountCard = "NO DISCOUNT CARD";
         percentage = 0;
    }

    public discount(String discountCard) {
        this.discountCard = discountCard;
        this.percentage= 15/100;
    }

    public String getDiscountCard() {
        return discountCard;
    }

    public double getPercentage() {
        return percentage;
    }

 
    public String toString() {
        return  "discountCard=" + discountCard + "percentage=" + percentage ;
    }

}

 