package com.parkey.model;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author la6of
 */

    public class Data {
    private String Name;
    private int NumOfKids;
    private int NumOfAdults;
    private String Email;
    private int PhoneNum;

    public Data(String Name, int NumOfKids, int NumOfAdults, String Email, int PhoneNum) {
        this.Name = Name;
        this.NumOfKids = NumOfKids;
        this.NumOfAdults = NumOfAdults;
        this.Email = Email;
        this.PhoneNum = PhoneNum;
    }

    public String getName() {
        return Name;
    }

    public int getNumOfKids() {
        return NumOfKids;
    }

    public int getNumOfAdults() {
        return NumOfAdults;
    }

    public String getEmail() {
        return Email;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public void setNumOfKids(int NumOfKids) {
        this.NumOfKids = NumOfKids;
    }

    public void setNumOfAdults(int NumOfAdults) {
        this.NumOfAdults = NumOfAdults;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public void setPhoneNum(int PhoneNum) {
        this.PhoneNum = PhoneNum;
    }

   
    public String toString() {
        return "\n Name=" + Name + "\n NumOfKids=" + NumOfKids + "\n NumOfAdults=" + NumOfAdults + "\n Email=" + Email + "\n PhoneNum=" + PhoneNum ;
    }

    
    

}



    
