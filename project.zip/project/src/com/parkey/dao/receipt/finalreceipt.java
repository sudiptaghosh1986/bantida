package com.parkey.dao.receipt;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author la6of
 */
public class finalreceipt {

    private int discount;
    private int totalTickets;
    private double totalAfterDiscount;

    public finalreceipt(int discount, int totalTickets) {
        this.totalTickets = totalTickets;
        this.discount = 15 / 100;
        this.totalAfterDiscount = totalTickets * discount;
    }

    public int getTotalTickets() {
        return totalTickets;
    }

    public double getTotalAfterDiscount() {
        return totalAfterDiscount;
    }

    public String toString() {
        return "totalTickets=" + totalTickets + "totalAfterDiscount" + totalAfterDiscount;
    }
}
